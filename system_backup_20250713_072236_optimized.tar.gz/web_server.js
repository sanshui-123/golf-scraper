#!/usr/bin/env node

/**
 * 稳定版高尔夫文章Web服务器
 * 增加端口检测、错误处理、文章删除功能和URL重复检查功能
 */

const express = require('express');
const path = require('path');
const fs = require('fs');
const http = require('http');

const app = express();
let PORT = process.env.PORT || 8080;

// 解析 JSON 请求体
app.use(express.json());

// 检查端口是否可用
function checkPort(port) {
    return new Promise((resolve) => {
        const server = http.createServer();
        server.listen(port, () => {
            server.close(() => {
                resolve(true);
            });
        });
        server.on('error', () => {
            resolve(false);
        });
    });
}

// 找到可用端口
async function findAvailablePort(startPort) {
    for (let port = startPort; port <= startPort + 10; port++) {
        if (await checkPort(port)) {
            return port;
        }
    }
    throw new Error('没有找到可用端口');
}

// 静态文件服务
app.use('/golf_content', express.static(path.join(__dirname, 'golf_content')));

// 改进的中文标题提取函数
function extractChineseTitle(htmlFilePath) {
    try {
        const content = fs.readFileSync(htmlFilePath, 'utf8');
        
        // 策略1: 查找<h1>标签中的中文内容（优先）
        const h1Matches = content.match(/<h1[^>]*>(.*?)<\/h1>/g);
        if (h1Matches) {
            for (const match of h1Matches) {
                const textContent = match.replace(/<[^>]*>/g, '').trim();
                // 检查是否包含中文字符
                if (/[\u4e00-\u9fa5]/.test(textContent) && textContent.length > 5) {
                    return textContent;
                }
            }
        }
        
        // 策略2: 查找第一个包含中文的<h2>标签
        const h2Matches = content.match(/<h2[^>]*>(.*?)<\/h2>/g);
        if (h2Matches) {
            for (const match of h2Matches) {
                const textContent = match.replace(/<[^>]*>/g, '').trim();
                if (/[\u4e00-\u9fa5]/.test(textContent) && textContent.length > 5) {
                    return textContent;
                }
            }
        }
        
        // 策略3: 查找<title>标签中的中文内容
        const titleMatch = content.match(/<title>(.*?)<\/title>/);
        if (titleMatch && titleMatch[1]) {
            const titleText = titleMatch[1].trim();
            if (/[\u4e00-\u9fa5]/.test(titleText) && titleText.length > 5) {
                return titleText;
            }
        }
        
        // 策略4: 查找第一个包含中文的段落（可能是标题段落）
        const pMatches = content.match(/<p[^>]*>(.*?)<\/p>/g);
        if (pMatches) {
            for (const match of pMatches.slice(0, 5)) { // 只检查前5个段落
                const textContent = match.replace(/<[^>]*>/g, '').trim();
                // 检查是否像标题（长度适中，包含中文，不包含过多标点）
                if (/[\u4e00-\u9fa5]/.test(textContent) && 
                    textContent.length > 10 && 
                    textContent.length < 100 &&
                    !textContent.includes('http') &&
                    !textContent.includes('@')) {
                    return textContent;
                }
            }
        }
        
        // 策略5: 使用文件名作为后备（转换为可读格式）
        const fileName = path.basename(htmlFilePath, '.html');
        if (fileName.includes('article_')) {
            return `高尔夫文章 ${fileName.replace('article_', '').replace('wechat_', '')}`;
        }
        
        return fileName.replace(/_/g, ' ');
        
    } catch (e) {
        console.error(`读取文件失败: ${htmlFilePath}`, e.message);
        return '读取失败';
    }
}

// 改进的原文链接提取函数
function extractSourceUrl(htmlFilePath) {
    try {
        const content = fs.readFileSync(htmlFilePath, 'utf8');
        
        // 更多的原文链接查找模式
        const patterns = [
            // 中文模式
            /原文链接[^>]*?href="([^"]+)"/,
            /查看原文[^>]*?href="([^"]+)"/,
            /原始链接[^>]*?href="([^"]+)"/,
            /source[^>]*?href="([^"]+)"/i,
            
            // HTML结构模式
            /<a[^>]+href="(https?:\/\/[^"]+)"[^>]*>.*?原文/,
            /<a[^>]+href="(https?:\/\/[^"]+)"[^>]*>.*?source/i,
            /<a[^>]+href="(https?:\/\/[^"]+)"[^>]*>.*?查看/,
            
            // 通用链接模式（golf网站）
            /href="(https?:\/\/[^"]*golf[^"]*)"[^>]*>/i,
            /href="(https?:\/\/www\.golf[^"]*)"[^>]*>/i,
            
            // source-info 类中的链接
            /source-info[^>]*>.*?href="([^"]+)"/,
            
            // 更宽泛的模式
            /"(https?:\/\/(?:www\.)?(?:golf\.com|golfmonthly\.com|mygolfspy\.com)[^"]*)"/ 
        ];
        
        for (const pattern of patterns) {
            const match = content.match(pattern);
            if (match && match[1] && match[1].startsWith('http')) {
                return match[1];
            }
        }
        
        return null;
    } catch (e) {
        console.error(`提取原文链接失败: ${htmlFilePath}`, e.message);
        return null;
    }
}

// URL检查功能 - 检查是否已存在该URL的文章
function checkUrlExists(targetUrl) {
    const results = {
        exists: false,
        foundIn: null,
        details: null
    };
    
    try {
        const baseDir = 'golf_content';
        
        if (!fs.existsSync(baseDir)) {
            return results;
        }
        
        // 获取所有日期目录
        const dateDirs = fs.readdirSync(baseDir)
            .filter(dir => {
                const fullPath = path.join(baseDir, dir);
                return fs.statSync(fullPath).isDirectory() && /^\d{4}-\d{2}-\d{2}$/.test(dir);
            })
            .sort().reverse();
        
        // 遍历每个日期目录
        for (const dateDir of dateDirs) {
            // 🔧 新增：首先检查article_urls.json
            const urlsJsonPath = path.join(baseDir, dateDir, 'article_urls.json');
            if (fs.existsSync(urlsJsonPath)) {
                try {
                    const urlMapping = JSON.parse(fs.readFileSync(urlsJsonPath, 'utf8'));
                    // 检查是否有匹配的URL
                    for (const [articleNum, recordedUrl] of Object.entries(urlMapping)) {
                        if (isSameUrl(recordedUrl, targetUrl)) {
                            // 找到匹配的URL，获取对应的HTML文件信息
                            const htmlFile = `wechat_article_${articleNum}.html`;
                            const htmlPath = path.join(baseDir, dateDir, 'wechat_html', htmlFile);
                            
                            if (fs.existsSync(htmlPath)) {
                                results.exists = true;
                                results.foundIn = {
                                    date: dateDir,
                                    filename: htmlFile,
                                    extractedUrl: recordedUrl,
                                    title: extractChineseTitle(htmlPath)
                                };
                                results.details = `文章已存在于 ${dateDir}/${htmlFile} (通过article_urls.json匹配)`;
                                console.log(`✅ 通过article_urls.json找到匹配: ${targetUrl} -> ${htmlFile}`);
                                return results;
                            }
                        }
                    }
                } catch (e) {
                    console.error(`读取 ${urlsJsonPath} 失败:`, e.message);
                }
            }
            
            // 原有逻辑：检查HTML文件中的原文链接
            const htmlDir = path.join(baseDir, dateDir, 'wechat_html');
            
            if (!fs.existsSync(htmlDir)) continue;
            
            const htmlFiles = fs.readdirSync(htmlDir)
                .filter(file => file.endsWith('.html') && !file.includes('backup'));
            
            // 检查每个HTML文件
            for (const file of htmlFiles) {
                const filePath = path.join(htmlDir, file);
                const extractedUrl = extractSourceUrl(filePath);
                
                if (extractedUrl && isSameUrl(extractedUrl, targetUrl)) {
                    results.exists = true;
                    results.foundIn = {
                        date: dateDir,
                        filename: file,
                        extractedUrl: extractedUrl,
                        title: extractChineseTitle(filePath)
                    };
                    results.details = `文章已存在于 ${dateDir}/${file} (通过HTML原文链接匹配)`;
                    return results;
                }
            }
        }
        
        return results;
        
    } catch (error) {
        console.error('URL检查失败:', error);
        results.details = `检查过程出错: ${error.message}`;
        return results;
    }
}

// URL比较函数 - 标准化URL后比较
function isSameUrl(url1, url2) {
    try {
        // 标准化URL
        const normalizeUrl = (url) => {
            return url
                .toLowerCase()
                .replace(/^https?:\/\//, '')  // 移除协议
                .replace(/^www\./, '')       // 移除www
                .replace(/\/$/, '')          // 移除末尾斜杠
                .replace(/\?.*$/, '')        // 移除查询参数
                .replace(/#.*$/, '');        // 移除锚点
        };
        
        const normalized1 = normalizeUrl(url1);
        const normalized2 = normalizeUrl(url2);
        
        return normalized1 === normalized2;
    } catch (error) {
        console.error('URL比较失败:', error);
        return false;
    }
}

// 批量URL检查
function checkMultipleUrls(urls) {
    const results = [];
    
    for (const url of urls) {
        const checkResult = checkUrlExists(url);
        results.push({
            url: url,
            exists: checkResult.exists,
            foundIn: checkResult.foundIn,
            details: checkResult.details
        });
    }
    
    return results;
}

// 获取所有日期列表
function getAllDates() {
    const dates = [];
    const baseDir = 'golf_content';
    
    try {
        if (!fs.existsSync(baseDir)) {
            console.log('golf_content目录不存在');
            return dates;
        }
        
        const dateDirs = fs.readdirSync(baseDir)
            .filter(dir => {
                const fullPath = path.join(baseDir, dir);
                return fs.statSync(fullPath).isDirectory() && /^\d{4}-\d{2}-\d{2}$/.test(dir);
            })
            .sort().reverse(); // 最新的在前面
        
        dateDirs.forEach(dateDir => {
            const htmlDir = path.join(baseDir, dateDir, 'wechat_html');
            if (fs.existsSync(htmlDir)) {
                const htmlFiles = fs.readdirSync(htmlDir)
                    .filter(file => file.endsWith('.html'));
                
                if (htmlFiles.length > 0) {
                    dates.push({
                        date: dateDir,
                        count: htmlFiles.length,
                        displayDate: new Date(dateDir + 'T00:00:00').toLocaleDateString('zh-CN', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                            weekday: 'long'
                        })
                    });
                }
            }
        });
        
        return dates;
    } catch (e) {
        console.error('获取日期列表失败:', e.message);
        return [];
    }
}

// 获取指定日期的所有文章
function getArticlesByDate(date) {
    const articles = [];
    const htmlDir = path.join('golf_content', date, 'wechat_html');
    
    try {
        if (!fs.existsSync(htmlDir)) {
            console.log(`目录不存在: ${htmlDir}`);
            return articles;
        }
        
        const htmlFiles = fs.readdirSync(htmlDir)
            .filter(file => file.endsWith('.html'))
            .sort();
        
        htmlFiles.forEach(file => {
            const filePath = path.join(htmlDir, file);
            try {
                const stats = fs.statSync(filePath);
                
                const chineseTitle = extractChineseTitle(filePath);
                const sourceUrl = extractSourceUrl(filePath);
                
                articles.push({
                    filename: file,
                    chineseTitle,
                    sourceUrl,
                    createdTime: stats.mtime,
                    articleUrl: `/golf_content/${date}/wechat_html/${file}`,
                    displayTime: new Date(stats.mtime).toLocaleString('zh-CN')
                });
            } catch (e) {
                console.error(`处理文件失败: ${file}`, e.message);
            }
        });
        
        return articles;
    } catch (e) {
        console.error('获取文章列表失败:', e.message);
        return [];
    }
}

// 删除文章的函数
function deleteArticleFiles(date, filename) {
    const results = {
        deletedFiles: [],
        errors: []
    };
    
    try {
        // 安全检查：验证日期格式
        if (!date.match(/^\d{4}-\d{2}-\d{2}$/)) {
            throw new Error('无效的日期格式');
        }
        
        // 安全检查：验证文件名（防止路径遍历攻击）
        if (!filename.match(/^[a-zA-Z0-9_\-\.]+\.html$/)) {
            throw new Error('无效的文件名格式');
        }
        
        const baseDir = path.join('golf_content', date);
        const baseName = filename.replace('.html', '');
        
        // 需要删除的文件路径列表
        const filesToDelete = [
            // HTML文件
            path.join(baseDir, 'wechat_html', filename),
            // Markdown文件
            path.join(baseDir, 'wechat_markdown', baseName + '.md'),
            // 可能的图片文件夹
            path.join(baseDir, 'wechat_images', baseName)
        ];
        
        // 删除文件
        for (const filePath of filesToDelete) {
            try {
                if (fs.existsSync(filePath)) {
                    const stats = fs.statSync(filePath);
                    
                    if (stats.isDirectory()) {
                        // 删除整个目录
                        fs.rmSync(filePath, { recursive: true, force: true });
                        results.deletedFiles.push(`目录: ${filePath}`);
                    } else {
                        // 删除单个文件
                        fs.unlinkSync(filePath);
                        results.deletedFiles.push(`文件: ${filePath}`);
                    }
                }
            } catch (error) {
                results.errors.push(`删除失败 ${filePath}: ${error.message}`);
            }
        }
        
        // 🆕 新增：清理 article_urls.json 中的记录
        const urlMapFile = path.join('golf_content', date, 'article_urls.json');
        if (fs.existsSync(urlMapFile)) {
            try {
                const urlMapping = JSON.parse(fs.readFileSync(urlMapFile, 'utf8'));
                const articleNum = filename.replace('wechat_article_', '').replace('.html', '');
                
                if (urlMapping[articleNum]) {
                    delete urlMapping[articleNum];
                    fs.writeFileSync(urlMapFile, JSON.stringify(urlMapping, null, 2), 'utf8');
                    results.deletedFiles.push(`URL映射: article_urls.json 中的编号 ${articleNum}`);
                    console.log(`✅ 已清理 article_urls.json 中的编号 ${articleNum}`);
                }
            } catch (e) {
                results.errors.push(`清理URL映射失败: ${e.message}`);
            }
        }
        
        return results;
        
    } catch (error) {
        results.errors.push(`删除操作失败: ${error.message}`);
        return results;
    }
}

// API: 检查单个URL是否已存在
app.get('/api/check-url', (req, res) => {
    try {
        const { url } = req.query;
        
        if (!url) {
            return res.status(400).json({
                success: false,
                message: '缺少URL参数'
            });
        }
        
        console.log(`🔍 检查URL: ${url}`);
        
        const result = checkUrlExists(url);
        
        res.json({
            success: true,
            url: url,
            exists: result.exists,
            foundIn: result.foundIn,
            details: result.details
        });
        
    } catch (error) {
        console.error('URL检查API错误:', error);
        res.status(500).json({
            success: false,
            message: '服务器内部错误',
            error: error.message
        });
    }
});

// API: 批量检查多个URL
app.post('/api/check-urls', (req, res) => {
    try {
        const { urls } = req.body;
        
        if (!urls || !Array.isArray(urls)) {
            return res.status(400).json({
                success: false,
                message: '请提供URL数组'
            });
        }
        
        console.log(`🔍 批量检查 ${urls.length} 个URL`);
        
        const results = checkMultipleUrls(urls);
        
        // 统计
        const existingCount = results.filter(r => r.exists).length;
        const newCount = results.length - existingCount;
        
        res.json({
            success: true,
            total: results.length,
            existing: existingCount,
            new: newCount,
            results: results
        });
        
    } catch (error) {
        console.error('批量URL检查API错误:', error);
        res.status(500).json({
            success: false,
            message: '服务器内部错误',
            error: error.message
        });
    }
});

// API: 删除文章
app.delete('/api/articles/:date/:filename', (req, res) => {
    try {
        const { date, filename } = req.params;
        
        console.log(`🗑️ 收到删除请求: ${date}/${filename}`);
        
        // 检查文件是否存在
        const htmlPath = path.join('golf_content', date, 'wechat_html', filename);
        if (!fs.existsSync(htmlPath)) {
            return res.status(404).json({
                success: false,
                message: '文章文件不存在'
            });
        }
        
        // 执行删除操作
        const deleteResults = deleteArticleFiles(date, filename);
        
        if (deleteResults.errors.length > 0) {
            console.error('删除过程中出现错误:', deleteResults.errors);
            return res.status(500).json({
                success: false,
                message: '删除过程中出现错误',
                errors: deleteResults.errors,
                deletedFiles: deleteResults.deletedFiles
            });
        }
        
        console.log(`✅ 删除成功: ${deleteResults.deletedFiles.join(', ')}`);
        
        res.json({
            success: true,
            message: '文章删除成功',
            deletedFiles: deleteResults.deletedFiles
        });
        
    } catch (error) {
        console.error('删除API错误:', error);
        res.status(500).json({
            success: false,
            message: '服务器内部错误',
            error: error.message
        });
    }
});

// 首页 - 显示日期列表
app.get('/', (req, res) => {
    try {
        const dates = getAllDates();
        
        const html = `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>高尔夫文章管理系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 2rem;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        .header {
            text-align: center;
            color: white;
            margin-bottom: 3rem;
        }
        .header h1 {
            font-size: 3rem;
            margin-bottom: 0.5rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        .header p {
            font-size: 1.2rem;
            opacity: 0.9;
        }
        .stats {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            text-align: center;
            color: white;
        }
        .dates-grid {
            display: grid;
            gap: 1.5rem;
        }
        .date-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            cursor: pointer;
            text-decoration: none;
            color: inherit;
        }
        .date-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .date-main {
            font-size: 1.8rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        .date-display {
            font-size: 1.1rem;
            color: #667eea;
            margin-bottom: 1rem;
        }
        .article-count {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: bold;
        }
        .no-dates {
            text-align: center;
            color: white;
            font-size: 1.2rem;
            margin-top: 3rem;
        }
        .server-info {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: rgba(255,255,255,0.9);
            padding: 10px;
            border-radius: 5px;
            font-size: 0.8rem;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏌️ 高尔夫文章</h1>
            <p>Golf Article Management System</p>
        </div>
        
        ${dates.length > 0 ? `
        <div class="stats">
            <div>
                共有 <strong>${dates.length}</strong> 个处理日期，
                总计 <strong>${dates.reduce((sum, d) => sum + d.count, 0)}</strong> 篇文章
            </div>
        </div>
        ` : ''}
        
        <div class="dates-grid">
            ${dates.length === 0 ? 
                '<div class="no-dates">📝 暂无文章，请先处理一些文章</div>' : 
                dates.map(date => `
                    <a href="/articles/${date.date}" class="date-card">
                        <div class="date-main">${date.date}</div>
                        <div class="date-display">${date.displayDate}</div>
                        <span class="article-count">📚 ${date.count} 篇文章</span>
                    </a>
                `).join('')
            }
        </div>
    </div>
    
    <div class="server-info">
        服务器运行在端口 ${PORT}
    </div>
</body>
</html>`;
        
        res.send(html);
    } catch (e) {
        console.error('首页渲染失败:', e.message);
        res.status(500).send('服务器错误');
    }
});

// 文章列表页 - 添加删除功能
app.get('/articles/:date', (req, res) => {
    try {
        const date = req.params.date;
        const articles = getArticlesByDate(date);
        
        const html = `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${date} - 文章列表</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f8f9fa;
            min-height: 100vh;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem 0;
            text-align: center;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem;
        }
        .back-btn {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 0.7rem 1.5rem;
            border-radius: 25px;
            text-decoration: none;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }
        .back-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        .articles-list {
            display: grid;
            gap: 1.5rem;
            margin-top: 2rem;
        }
        .article-item {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
        }
        .article-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .article-item.deleting {
            opacity: 0.5;
            transform: scale(0.95);
        }
        .article-title {
            font-size: 1.3rem;
            font-weight: bold;
            color: #2c3e50;
            text-decoration: none;
            display: block;
            margin-bottom: 1rem;
            line-height: 1.4;
        }
        .article-title:hover {
            color: #667eea;
        }
        .article-meta {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        .meta-left {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .source-btn {
            background: #28a745;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        .source-btn:hover {
            background: #218838;
        }
        .publish-time {
            color: #6c757d;
            font-size: 0.9rem;
        }
        .delete-btn {
            background: #dc3545;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }
        .delete-btn:hover:not(:disabled) {
            background: #c82333;
            transform: scale(1.05);
        }
        .delete-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
        }
        
        /* 确认对话框样式 */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s ease;
        }
        .modal-content {
            background-color: white;
            margin: 15% auto;
            padding: 2rem;
            border-radius: 12px;
            width: 90%;
            max-width: 400px;
            text-align: center;
            animation: slideIn 0.3s ease;
        }
        .modal h3 {
            color: #dc3545;
            margin-bottom: 1rem;
        }
        .modal p {
            margin-bottom: 1.5rem;
            color: #666;
        }
        .modal-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
        }
        .modal-btn {
            padding: 0.7rem 1.5rem;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        .modal-btn.confirm {
            background: #dc3545;
            color: white;
        }
        .modal-btn.confirm:hover {
            background: #c82333;
        }
        .modal-btn.cancel {
            background: #6c757d;
            color: white;
        }
        .modal-btn.cancel:hover {
            background: #5a6268;
        }
        
        /* 通知样式 */
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            color: white;
            font-weight: bold;
            z-index: 1001;
            animation: slideInRight 0.3s ease;
        }
        .notification.success {
            background: #28a745;
        }
        .notification.error {
            background: #dc3545;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        @keyframes slideInRight {
            from { transform: translateX(100%); }
            to { transform: translateX(0); }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="container">
            <a href="/" class="back-btn">← 返回日期列表</a>
            <h1>${date}</h1>
            <p>共 ${articles.length} 篇文章</p>
        </div>
    </div>
    
    <div class="container">
        <div class="articles-list">
            ${articles.length === 0 ? 
                '<div style="text-align: center; color: #6c757d; margin-top: 3rem;">📝 该日期暂无文章</div>' : 
                articles.map(article => `
                    <div class="article-item" data-filename="${article.filename}">
                        <a href="${article.articleUrl}" class="article-title" target="_blank">
                            ${article.chineseTitle}
                        </a>
                        <div class="article-meta">
                            <div class="meta-left">
                                ${article.sourceUrl ? 
                                    `<a href="${article.sourceUrl}" class="source-btn" target="_blank">🔗 查看原文</a>` : 
                                    '<span style="color: #6c757d;">暂无原文链接</span>'
                                }
                                <span class="publish-time">📅 ${article.displayTime}</span>
                            </div>
                            <button class="delete-btn" onclick="confirmDelete('${article.filename}', '${article.chineseTitle}')">
                                🗑️ 删除
                            </button>
                        </div>
                    </div>
                `).join('')
            }
        </div>
    </div>
    
    <!-- 确认删除对话框 -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <h3>⚠️ 确认删除</h3>
            <p id="deleteMessage">确定要删除这篇文章吗？</p>
            <div class="modal-buttons">
                <button class="modal-btn cancel" onclick="cancelDelete()">取消</button>
                <button class="modal-btn confirm" onclick="executeDelete()">确认删除</button>
            </div>
        </div>
    </div>
    
    <script>
        let deleteFilename = '';
        
        // 显示确认删除对话框
        function confirmDelete(filename, title) {
            deleteFilename = filename;
            document.getElementById('deleteMessage').textContent = 
                \`确定要删除文章《\${title}》吗？此操作不可撤销！\`;
            document.getElementById('deleteModal').style.display = 'block';
        }
        
        // 取消删除
        function cancelDelete() {
            document.getElementById('deleteModal').style.display = 'none';
            deleteFilename = '';
        }
        
        // 执行删除
        async function executeDelete() {
            if (!deleteFilename) return;
            
            // 关闭对话框
            document.getElementById('deleteModal').style.display = 'none';
            
            // 找到对应的文章项并添加删除动画
            const articleItem = document.querySelector(\`[data-filename="\${deleteFilename}"]\`);
            if (articleItem) {
                articleItem.classList.add('deleting');
            }
            
            // 禁用删除按钮
            const deleteBtn = articleItem?.querySelector('.delete-btn');
            if (deleteBtn) {
                deleteBtn.disabled = true;
                deleteBtn.textContent = '删除中...';
            }
            
            try {
                const response = await fetch(\`/api/articles/${date}/\${deleteFilename}\`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                
                const result = await response.json();
                
                if (result.success) {
                    // 删除成功
                    showNotification('文章删除成功！', 'success');
                    
                    // 动画移除元素
                    if (articleItem) {
                        setTimeout(() => {
                            articleItem.style.height = articleItem.offsetHeight + 'px';
                            articleItem.style.transition = 'all 0.3s ease';
                            setTimeout(() => {
                                articleItem.style.height = '0';
                                articleItem.style.opacity = '0';
                                articleItem.style.marginBottom = '0';
                                articleItem.style.padding = '0';
                            }, 50);
                            setTimeout(() => {
                                articleItem.remove();
                                
                                // 检查是否还有文章
                                const remaining = document.querySelectorAll('.article-item').length;
                                if (remaining === 0) {
                                    location.reload(); // 刷新页面显示"暂无文章"
                                }
                            }, 350);
                        }, 500);
                    }
                } else {
                    // 删除失败
                    showNotification(\`删除失败: \${result.message}\`, 'error');
                    
                    // 恢复按钮状态
                    if (articleItem) {
                        articleItem.classList.remove('deleting');
                    }
                    if (deleteBtn) {
                        deleteBtn.disabled = false;
                        deleteBtn.innerHTML = '🗑️ 删除';
                    }
                }
            } catch (error) {
                console.error('删除请求失败:', error);
                showNotification('删除请求失败，请检查网络连接', 'error');
                
                // 恢复按钮状态
                if (articleItem) {
                    articleItem.classList.remove('deleting');
                }
                if (deleteBtn) {
                    deleteBtn.disabled = false;
                    deleteBtn.innerHTML = '🗑️ 删除';
                }
            }
            
            deleteFilename = '';
        }
        
        // 显示通知
        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.className = \`notification \${type}\`;
            notification.textContent = message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }
        
        // 点击模态框外部关闭
        window.onclick = function(event) {
            const modal = document.getElementById('deleteModal');
            if (event.target === modal) {
                cancelDelete();
            }
        }
    </script>
</body>
</html>`;
        
        res.send(html);
    } catch (e) {
        console.error('文章列表页渲染失败:', e.message);
        res.status(500).send('服务器错误');
    }
});

// 错误处理
app.use((err, req, res, next) => {
    console.error('服务器错误:', err);
    res.status(500).send('服务器内部错误');
});

// 启动服务器
async function startServer() {
    try {
        // 检查并找到可用端口
        PORT = await findAvailablePort(PORT);
        
        app.listen(PORT, () => {
            console.log(`🚀 高尔夫文章Web服务器已启动`);
            console.log(`📖 访问地址: http://localhost:${PORT}`);
            console.log(`📋 首页显示日期列表，点击日期查看文章`);
            console.log(`🗑️ 已添加文章删除功能`);
            console.log(`🔍 已添加URL重复检查功能`);
            console.log(`📡 API端点: /api/check-url?url=xxx 和 /api/check-urls`);
            
            const dates = getAllDates();
            console.log(`📊 当前共有 ${dates.length} 个日期，${dates.reduce((sum, d) => sum + d.count, 0)} 篇文章`);
        });
        
    } catch (error) {
        console.error('启动服务器失败:', error.message);
        console.log('请尝试手动指定端口：PORT=3000 node web_server.js');
        process.exit(1);
    }
}

// 优雅关闭
process.on('SIGINT', () => {
    console.log('\n👋 服务器正在关闭...');
    process.exit(0);
});

// 启动
startServer();